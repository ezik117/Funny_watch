#pragma once
#include "variables.h"

/*##############################################################################
#
# ОПИСАНИЕ: ВСПОМОГАТЕЛЬНЫЕ ЭЛЕМЕНТЫ МОДУЛЯ MAIN
# ФАЙЛ: main.h
#
##############################################################################*/

void ConvertToBCD(uint16_t data);
void UsartSendData(uint8_t *data, uint8_t dataLen);

volatile uint16_t ticks;         // для подсчета длины импульса
volatile bool start = FALSE;     // флаг запуска/останова счетчика длины импульса
volatile uint16_t data;          // полученные данные
volatile bool gotData = FALSE;   // флаг того, что фрейм получен

volatile uint8_t pos;            // указатель на буфер приема
volatile uint16_t buffer[7];              // буфер приема

uint8_t dataBuf[6] = {0,0,0,0,'\r','\n'};
uint8_t* uTxData; // указатель на данные для передачи
volatile uint8_t uTxLen; // длина передаваемых данных


uint16_t xprg[6] = {4000, 100, 750, 100, 400, 100}; // симуляция хлопков
//uint16_t xprg[6] = {500, 1000, 500, 1000, 500, 1000}; // 0-LO, 1-HI, 2-LO ...
bool inverted = TRUE; // TRUE: первый байт xprg-сигнал HI, FALSE: сигнал LO
volatile uint8_t xpos = 0;
volatile uint16_t xticks = 0;