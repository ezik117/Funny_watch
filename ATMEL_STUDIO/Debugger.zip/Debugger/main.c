#include "stm32f030x6.h"
#include "stm32f0xx.h"
#include "main.h"
#include "variables.h"
#include "functions.h"

/*##############################################################################
# МИКРОПРОЦЕССОР: stm32f030f4
# ОПИСАНИЕ НАЗНАЧЕНИЯ ПРОГРАММЫ ЗДЕСЬ
#
##############################################################################*/



/*
ПИНЫ:
PA2 - USART Tx
PA4 - вход
PA3 - симуляция сигнала
*/

int main()
{
  // Включить прерывания
  __enable_irq();
  
  //--- перевести MCU на тактовую частоту 48МГц (HSI/2) ---
  MODIFY_REG(RCC->CFGR, RCC_CFGR_PLLMUL_Msk, RCC_CFGR_PLLMUL12); //задать множитель PLL x12 (HSI/2*12=48MHz)
  SET_BIT(RCC->CR, RCC_CR_PLLON); //включить PLL
  while((RCC->CR & RCC_CR_PLLRDY) == 0); //дождаться включения PLL
    
  SET_BIT(RCC->CFGR, (uint32_t)RCC_CFGR_SW_PLL); //выбрать PLL источником SYSCLK
  while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL); //дождаться пока PLL не включится как источник SYSCLK

  // ТАКТИРОВАНИЕ
  SET_BIT(RCC->AHBENR, RCC_AHBENR_GPIOAEN);
  SET_BIT(RCC->APB2ENR, RCC_APB2ENR_USART1EN); //включить тактирование USART1  
  
  // GPIO
  SET_BIT(GPIOA->MODER, GPIO_MODER_MODER3_0); // PA3 - out
  SET_BIT(GPIOA->OSPEEDR, GPIO_OSPEEDR_OSPEEDR3);
  if (inverted)
    GPIOA->BSRR = GPIO_BSRR_BS_3; // set to "1"
  else
    GPIOA->BSRR = GPIO_BSRR_BR_3; // set to "0"
  
  // USART
  SET_BIT(GPIOA->MODER, (GPIO_MODER_MODER2_1)); // PA2-альтернативная функция AF1(USART)
  SET_BIT(GPIOA->OSPEEDR, (GPIO_OSPEEDR_OSPEEDR2));
  GPIOA->AFR[0] = 1U << GPIO_AFRL_AFRL2_Pos; // AF1(USART)
  
  //--- конфигурируем USART1 (full-duplex, 8bit, 1stop bit, no parity, no hardware flow control)
  USART1->BRR = 0x1A1; // 115110
  USART1->CR1 = USART_CR1_UE; //UART enable 
  
  // GPIO interrupts
  SET_BIT(RCC->APB2ENR, RCC_APB2ENR_SYSCFGEN);
  SYSCFG->EXTICR[1] = SYSCFG_EXTICR2_EXTI4_PA;
  SET_BIT(EXTI->IMR, EXTI_IMR_IM4);
  SET_BIT(EXTI->RTSR, EXTI_RTSR_RT4);
  SET_BIT(EXTI->FTSR, EXTI_FTSR_TR4);
  NVIC_EnableIRQ(EXTI4_15_IRQn);
  
  // Реализация функции Delay (тактовая частота SYSCLK = 8МГц)
  SysTick->LOAD = (48000UL & SysTick_LOAD_RELOAD_Msk) - 1;
  SysTick->VAL = 0;
  SysTick->CTRL  = SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_TICKINT_Msk | SysTick_CTRL_ENABLE_Msk;
  
  
  while (1)
  {
//    if (gotData)
//    {
//      for (uint8_t i=0; i<7; i++)
//      {
//        ConvertToBCD(buffer[i]);
//        UsartSendData(&dataBuf[0], 7);
//      }
//      UsartSendData(&dataBuf[4], 2); // new line
//      gotData = FALSE;
//    }

    if (gotData)
    {
      ConvertToBCD(data);
      UsartSendData(&dataBuf[0], 7);
      gotData = FALSE;
    }
  }
}

//=== NVIC функции =============================================================

// Прерывание для реализации функции Delay -------------------------------------
void SysTick_Handler()
{
  if (start) ticks++;
  
  // симуляция сигнала
  xticks++;
  if (xticks >= xprg[xpos])
  {
    TOGGLE_BIT(GPIOA->ODR, GPIO_ODR_3);
    xticks = 0;
    xpos++;
    if (xpos == 6) xpos = 0;
  }
}


// Внешнее прерывание (HI to LO, или LO to HI)
/*
Протокол:
150мс - начало фрейма
50мс -  передача "1"
25мс -  передача "0"
100мс - конец фрейма
пауза ("0") между импульсами 10мс

200мс - начало последовательности
*/
void EXTI4_15_IRQHandler()
{
  if (!gotData) // если данные еще не обработаны не реагируем на входящие сигналы
  {
    if (EXTI->PR & EXTI_PR_PR4) // проверим какая линия вызвала прерывание
    {
      if (READ_BIT(GPIOA->IDR, GPIO_IDR_4) == GPIO_IDR_4)
      {
        // восходящий
        ticks = 0;
        start = TRUE;
      }
      else
      {
        // нисходящий
        start = FALSE;
        
        if (ticks < 40) // "0"
        {
          data >>= 1;
        }
        else if (ticks < 70) // "1"
        {
          data >>= 1;
          data |= 0x8000; // 0x80 для 8-битного, 0x8000 для 16-битного числа
        }
        else if (ticks < 130) // конец фрейма
        {
          gotData = TRUE;
          
          buffer[pos++] = data;
          if (pos >= 7)
          {
            gotData = TRUE;
          }
        }
        else if (ticks < 200) // начало фрейма
        {
          data = 0;
        }
        else if (ticks < 270) // начало последовательности
        {
          pos = 0;
        }
      }
    }
  }
  
  EXTI->PR = 0x7FFFFF; // сбросим все биты прерывания
}


//------------------------------------------------------------------------------
/* преобразует десяитичное число в BCD. Максимальное значение 9999 */
void ConvertToBCD(uint16_t data)
{
  dataBuf[0] = '0' + (data / 1000);
  data = data % 1000;
  dataBuf[1] = '0' + (data / 100);
  data = data % 100;
  dataBuf[2] = '0' + (data / 10);
  data = data % 10;
  dataBuf[3] = '0' + data;
}

//------------------------------------------------------------------------------
/* отправляет данные через USART. блокирующая ф-я */
void UsartSendData(uint8_t *data, uint8_t dataLen)
{
  SET_BIT(USART1->CR1, USART_CR1_TE); // /(Tx buffer empty) interrupt enable, Transmit enable
  while (dataLen-- > 0)
  {
    USART1->TDR = *data++;
    WAIT_SET(USART1->ISR, USART_ISR_TC); // ждем окончания передачи данных
  }

  CLEAR_BIT(USART1->CR1, (USART_CR1_TE)); // отключаем Transmit ISR
}